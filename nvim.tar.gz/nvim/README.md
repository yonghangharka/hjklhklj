# My Neovim Config

Based on: [🚀Launch.nvim](https://github.com/LunarVim/Launch.nvim)
