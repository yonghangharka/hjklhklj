local M = {
  "user/repo",
  event = "VeryLazy",
}

function M.config()
end

return M
