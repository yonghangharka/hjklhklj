return {
  settings = {
    css = {
      lint = {
        unknownAtRules = "ignore",
      },
      format = {
        enable = false,
      },
      -- customData = { ".css-data.json" },
    },
  },
}
