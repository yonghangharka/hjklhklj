local M = {
  "tpope/vim-sleuth",
  "MaxMEllon/vim-jsx-pretty",
}

function M.config() end

return M
