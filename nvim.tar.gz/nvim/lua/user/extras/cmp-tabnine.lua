local M = {
    "tzachar/cmp-tabnine",
    event = "InsertEnter",
    build = "./install.sh",
}

function M.config() end

return M
-- {
-- },
