local M = {
  "LeonHeidelbach/trailblazer.nvim",
  event = "BufReadPre",
}

return M
