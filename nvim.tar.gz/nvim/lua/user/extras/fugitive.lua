local M = {
  "tpope/vim-fugitive",
  event = "VeryLazy",
}

function M.config() end

return M
