local M = {
  "MunifTanjim/nui.nvim",
  event = "VeryLazy",
}

function M.config() end

return M
