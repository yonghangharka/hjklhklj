local M = {
  "00sapo/visual.nvim",
  event = "VeryLazy",
}

function M.config()
end

return M
